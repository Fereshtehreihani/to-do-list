var dropbtn = document.getElementById('tagOptions');
var dropdownContent = document.getElementById('myDropdown');
var taskTags = document.querySelectorAll('.dropdown__content a');
var taskInput = document.getElementById('taskInput');

function toggleFormVisibility() {
    var formButton = document.getElementById('showFormButton');
    var taskForm = document.getElementById('taskForm');

    if (formButton.style.display == 'block') {
        formButton.style.display = 'none';
        taskForm.style.display = 'block';
    } else {
        formButton.style.display = 'block';
        taskForm.style.display = 'none';
    }
}
document.getElementById('showFormButton').onclick = toggleFormVisibility;

function toggleDropdown() {
    if (isInputNotEmpty()) {
        dropdownContent.style.display = 'block';
    } else {
        dropdownContent.style.display = 'none';
    }
}

function isInputNotEmpty() {
    return taskInput.value.trim() !== '';
}

function selectTag(tag) {
    if (isInputNotEmpty()) {
        taskTags.forEach(function(innerTag) {
            if (innerTag !== tag) {
                innerTag.style.display = 'none';
            }
        });
        dropdownContent.style.display = 'block';
    }
}

function closeDropdown(event) {
    if (event.target.matches('#addTaskButton')) {
        dropdownContent.style.display = 'none';
    }
}

dropbtn.onclick = toggleDropdown;

taskTags.forEach(function(tag) {
    tag.onclick = function(event) {
        event.stopPropagation();
        selectTag(tag);
    };
});

// enent to close dropdown
window.onclick = closeDropdown;

//add tasks
document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('showFormButton').addEventListener('onclick', () => {
        document.getElementById('taskForm').classList.toggle('hidden');
    });

    document.getElementById('addTaskButton').addEventListener('click', addTask);
    document.getElementById('tagOptions').addEventListener('click', showDropdown);
    document.querySelectorAll('#myDropdown a').forEach((tag) => {
        tag.addEventListener('click', selectTag);
    });
});

function addTask() {
    const taskInput = document.getElementById('taskInput');
    if (taskInput.value.trim() === '') {
        alert('لطفا یک تسک خالی وارد نکنید.');
        return; // Prevent adding an empty task
    }

    const taskList = document.getElementById('taskList');
    const newTask = document.createElement('li');
    newTask.classList.add('task-item');

    // Add checkbox icon
    const checkbox = document.createElement('span');
    checkbox.classList.add('checkbox');
    checkbox.innerHTML = '☐'; // Unicode for empty square
    checkbox.addEventListener('click', toggleTaskStatus);
    newTask.appendChild(checkbox);

    // Add task text
    const taskText = document.createElement('span');
    taskText.classList.add('task-text');
    taskText.textContent = taskInput.value;
    newTask.appendChild(taskText);

    // Add delete icon
    const deleteIcon = document.createElement('span');
    deleteIcon.classList.add('delete');
    deleteIcon.innerHTML = '<img src="/images/Frame 33317.png">'; // Unicode for trash bin
    deleteIcon.addEventListener('click', () => {
        newTask.remove();
        updateTaskCounts();
        saveTasks(); // Save tasks after deletion
    });
    newTask.appendChild(deleteIcon);

    // Add tag text to the task with style
    const tag = document.createElement('span');
    tag.classList.add('tag');
    const selectedTag = document.querySelector('#myDropdown a.selected');
    if (selectedTag) {
        // Copy all classes from the selected tag
        selectedTag.classList.forEach(cls => {
            tag.classList.add(cls);
        });
        // Set the color based on the tag's text
        switch (selectedTag.textContent) {
            case 'بالا':
                tag.style.backgroundColor = '#FFE2DB';
                tag.style.color='#FF5F37'; 
                break;
            case 'متوسط':
                tag.style.backgroundColor = '#FFEFD6';
                tag.style.color='#FFAF37';
                break;
            case 'پایین':
                tag.style.backgroundColor = '#C3FFF1';
                tag.style.color='#11A483'; 
                break;
            default:
                tag.style.backgroundColor = 'gray'; // Default color
        }
        tag.textContent = selectedTag.textContent;
    } else {
        tag.textContent = 'بدون تگ';
        tag.style.backgroundColor = 'gray'; // Default color for no tag
    }
    newTask.appendChild(tag);

    taskList.appendChild(newTask);

    // Reset the input field and dropdown
    taskInput.value = '';
    resetDropdown();

    // Update task counts and save to local storage
    updateTaskCounts();
    saveTasks(); // Save tasks after addition
}


function toggleTaskStatus() {
    this.innerHTML = this.innerHTML === '☐' ? '<img src="/Frame 1000005437.png">' : '☐'; // Toggle between empty square and checkmark
    this.parentNode.classList.toggle('completed');
    saveTasks();
}

function updateTaskCounts() {

    const taskList = document.getElementById('taskList');
    const tasks = document.querySelectorAll('#taskList .task-item');
    const completedTasks = Array.from(tasks).filter(task => task.classList.contains('completed'));
    const undoneTasks = Array.from(tasks).filter(task => !task.classList.contains('completed'));

    // Clear the task list but keep the separator
    taskList.innerHTML = ''; 
    const separator = document.createElement('li');
    separator.classList.add('separator');
    const separatorImg = document.createElement('img');
    separatorImg.src = "/Frame 1000005523.png"; 
    separator.appendChild(separatorImg);
    taskList.appendChild(separator);

    undoneTasks.forEach(task => taskList.insertBefore(task, separator));
    completedTasks.forEach(task => taskList.appendChild(task));
    const doneCount = completedTasks.length;
    const undoneCount = undoneTasks.length;

    document.getElementById('doneCount').textContent = 'تسک های انجام شده : ' + doneCount;
    document.getElementById('undoneCount').textContent = 'تسک های انجام نشده : ' + undoneCount;
  saveTasks();
}

function saveTasks() {
    const tasks = [];
    document.querySelectorAll('#taskList .task-item').forEach(task => {
        tasks.push({
            text: task.querySelector('.task-text').textContent,
            completed: task.classList.contains('completed'),
            tag: task.querySelector('.tag').textContent
        });
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks'));
    if (tasks) {
        tasks.forEach(task => {
            const newTask = document.createElement('li');
            newTask.classList.add('task-item');

            // Add checkbox icon
            const checkbox = document.createElement('span');
            checkbox.classList.add('checkbox');
            checkbox.innerHTML = task.completed ? '<img src="/Frame 1000005437.png">' : '☐'; // Checkmark or empty square
            checkbox.addEventListener('click', toggleTaskStatus);
            newTask.appendChild(checkbox);

            // Add task text
            const taskText = document.createElement('span');
            taskText.classList.add('task-text');
            taskText.textContent = task.text;
            newTask.appendChild(taskText);

            // Add delete icon
            const deleteIcon = document.createElement('span');
            deleteIcon.classList.add('delete');
            deleteIcon.innerHTML = '<img src="/images/Frame 33317.png">';
            deleteIcon.addEventListener('click', () => {
                newTask.remove();
                updateTaskCounts();
                saveTasks();
            });
            newTask.appendChild(deleteIcon);

            // Add tag text to the task
            const tag = document.createElement('span');
            tag.classList.add('tag');
            tag.textContent = task.tag || 'بدون تگ';
            newTask.appendChild(tag);

            if (task.completed) {
                newTask.classList.add('completed');
            }

            document.getElementById('taskList').appendChild(newTask);
        });
    }
    updateTaskCounts();
}

function resetDropdown() {
    const dropdownLinks = document.querySelectorAll('#myDropdown a');
    dropdownLinks.forEach(link => {
        link.classList.remove('selected');
        link.style.display = 'block';
    });
}

function showDropdown() {
    document.getElementById('myDropdown').classList.toggle('show');
}

function selectTag() {
    document.querySelectorAll('#myDropdown a').forEach((tag) => {
        tag.classList.remove('selected');
    });
    this.classList.add('selected');
}


// Close the dropdown if the user clicks outside of it
window.addEventListener('click', (event) => {
    if (!event.target.matches('#tagOptions')) {
        var dropdowns = document.getElementsByClassName('dropdown__content');
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
});

document.addEventListener('DOMContentLoaded', loadTasks);

